document.addEventListener('DOMContentLoaded', () => {
  const newsGrid = document.getElementById('newsGrid');
  if (newsGrid) {
    const newsItems = [
      { title: "NHREC releases new ethics guideline", date: "Oct 2025" },
      { title: "Call for proposals in public health ethics", date: "Sep 2025" },
      { title: "Annual conference announced", date: "Aug 2025" }
    ];
    newsItems.forEach(n => {
      const div = document.createElement('div');
      div.className = 'card';
      div.innerHTML = `<h4>${n.title}</h4><p><small>${n.date}</small></p>`;
      newsGrid.appendChild(div);
    });
  }
});
